#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED

#define WALK 0
#define STAY 1
#define JUMP 2
#define RIGHT 0
#define LEFT 1

struct Player
{
    float velocity = 4.5;
    float jumpHeight=-10.0;
    float gravity=19.0;
    float posX=512.0;
    float posY=100.0;
    bool isOnFloor = true;
    bool lookRight = true;
    int frameLine = 1;
};
extern Player player;

void Player_Move();
float checkCollisionHorizontal(float deltaX, float deltaY, int side);
int checkCollisionVertical(float deltaX, float deltaY, int side);


#endif // PLAYER_H_INCLUDED
